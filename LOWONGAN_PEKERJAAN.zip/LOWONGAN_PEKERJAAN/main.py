from flask import Flask, render_template, request, redirect, flash, session
from flask_mysqldb import MySQL
from functools import wraps

app = Flask(__name__)
app.secret_key = 'rahasia'

# Konfigurasi koneksi database MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'dblowongan'

# Inisialisasi MySQL
db = MySQL(app)

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            flash("Silakan login terlebih dahulu.", "warning")
            return redirect('/login')
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    return render_template('user/index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cursor = db.connection.cursor()
        cursor.execute("SELECT * FROM user WHERE username=%s AND password=%s", (username, password))
        data = cursor.fetchone()
        if data:
            session['user'] = username
            session['user_id'] = data[0]
            return redirect('/admin/home')
        else:
            flash('Username atau password salah!', 'danger')
            return redirect('/login')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        password_confirm = request.form['password_confirm']
        if password != password_confirm:
            flash('Konfirmasi password tidak cocok!', 'danger')
            return redirect('/register')
        cursor = db.connection.cursor()
        cursor.execute("SELECT * FROM user WHERE username = %s", (username,))
        if cursor.fetchone():
            flash('Username sudah digunakan!', 'warning')
            return redirect('/register')
        cursor.execute("INSERT INTO user (username, password) VALUES (%s, %s)", (username, password))
        db.connection.commit()
        flash('Registrasi berhasil! Silakan login.', 'success')
        return redirect('/login')
    return render_template('register.html')

@app.route('/tentang')
def tentang():
    return render_template('user/tentang.html')

@app.route('/kontak')
def kontak():
    return render_template('user/kontak.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    session.pop('user_id', None)
    return redirect('/login')

@app.route('/admin/home')
@login_required
def home():
    return render_template('admin/index.html')

@app.route('/admin/kelola-lowongan')
@login_required
def kelola_lowongan():
    try:
        cursor = db.connection.cursor()
        cursor.execute("SELECT * FROM lowongan")
        data = cursor.fetchall()
    except Exception as e:
        flash(f"Gagal mengambil data: {e}", "danger")
        data = []
    return render_template('admin/lowongan.html', hasil=data)

@app.route('/admin/tambah-lowongan', methods=['GET', 'POST'])
@login_required
def tambah_lowongan():
    if request.method == 'POST':
        judul = request.form['judul']
        perusahaan = request.form['perusahaan']
        lokasi = request.form['lokasi']
        gaji = request.form['gaji']
        deskripsi = request.form['deskripsi']
        deadline = request.form['deadline']
        status = request.form['status']
        try:
            cursor = db.connection.cursor()
            sql = """
                INSERT INTO lowongan (judul, perusahaan, lokasi, gaji, deskripsi, deadline, status)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            cursor.execute(sql, (judul, perusahaan, lokasi, gaji, deskripsi, deadline, status))
            db.connection.commit()
            flash("Lowongan berhasil ditambahkan!", "success")
            return redirect('/admin/kelola-lowongan')
        except Exception as e:
            flash(f'Gagal menambah lowongan: {e}', 'danger')
    return render_template('admin/formtambahlowongan.html')

@app.route('/admin/edit-lowongan/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_lowongan(id):
    if request.method == 'POST':
        judul = request.form['judul']
        perusahaan = request.form['perusahaan']
        lokasi = request.form['lokasi']
        gaji = request.form['gaji']
        deskripsi = request.form['deskripsi']
        deadline = request.form['deadline']
        status = request.form['status']
        try:
            cursor = db.connection.cursor()
            sql = """
                UPDATE lowongan SET judul=%s, perusahaan=%s, lokasi=%s, gaji=%s, deskripsi=%s, deadline=%s, status=%s
                WHERE id=%s
            """
            cursor.execute(sql, (judul, perusahaan, lokasi, gaji, deskripsi, deadline, status, id))
            db.connection.commit()
            flash("Lowongan berhasil diupdate!", "success")
            return redirect('/admin/kelola-lowongan')
        except Exception as e:
            flash(f'Terjadi kesalahan: {e}', 'danger')

    try:
        cursor = db.connection.cursor()
        cursor.execute("SELECT * FROM lowongan WHERE id=%s", (id,))
        data = cursor.fetchone()
    except Exception as e:
        flash(f'Gagal mengambil data: {e}', 'danger')
        return redirect('/admin/kelola-lowongan')
    return render_template('admin/formeditlowongan.html', lowongan=data)

@app.route('/admin/hapus-lowongan/<int:id>', methods=['POST'])
@login_required
def hapus_lowongan(id):
    try:
        cursor = db.connection.cursor()
        cursor.execute("DELETE FROM lowongan WHERE id = %s", (id,))
        db.connection.commit()
        flash("Lowongan berhasil dihapus.", "success")
    except Exception as e:
        flash(f"Gagal menghapus lowongan: {e}", "danger")
    return redirect('/admin/kelola-lowongan')

@app.route('/admin/admin-kelola-user')
@login_required
def kelolauser():
    try:
        cursor = db.connection.cursor()
        cursor.execute("SELECT * FROM user")
        data = cursor.fetchall()
    except Exception as e:
        flash(f"Gagal mengambil data: {e}", "danger")
        data = []
    return render_template('admin/user.html', hasil=data)

@app.route('/admin/form-tambah-user', methods=['GET', 'POST'])
@login_required
def formuser():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        try:
            cursor = db.connection.cursor()
            cursor.execute("INSERT INTO user (username, password) VALUES (%s, %s)", (username, password))
            db.connection.commit()
            flash("Data user berhasil ditambahkan!", "success")
            return redirect('/admin/admin-kelola-user')
        except Exception as e:
            flash(f'Terjadi kesalahan: {e}', 'danger')
    return render_template('admin/formuser.html')

@app.route('/admin/form-edit-user/<int:id>', methods=['GET', 'POST'])
@login_required
def formedituser(id):
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        try:
            cursor = db.connection.cursor()
            sql = "UPDATE user SET username=%s, password=%s WHERE id=%s"
            cursor.execute(sql, (username, password, id))
            db.connection.commit()
            flash("Data user berhasil diupdate!", "success")
            return redirect('/admin/admin-kelola-user')
        except Exception as e:
            flash(f'Terjadi kesalahan: {e}', 'danger')

    try:
        cursor = db.connection.cursor()
        cursor.execute("SELECT * FROM user WHERE id=%s", (id,))
        data = cursor.fetchone()
    except Exception as e:
        flash(f'Gagal mengambil data: {e}', 'danger')
        return redirect('/admin/admin-kelola-user')
    return render_template('admin/formedituser.html', user=data)

@app.route('/admin/hapus-user/<int:id>', methods=['POST'])
@login_required
def hapus_user(id):
    try:
        cursor = db.connection.cursor()
        cursor.execute("DELETE FROM user WHERE id = %s", (id,))
        db.connection.commit()
        flash("User berhasil dihapus.", "success")
    except Exception as e:
        flash(f"Gagal menghapus user: {e}", "danger")
    return redirect('/admin/admin-kelola-user')

if __name__ == '__main__':
    app.run(debug=True)
